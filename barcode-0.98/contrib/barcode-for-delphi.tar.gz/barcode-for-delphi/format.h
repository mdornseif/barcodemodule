
int format_coordinates( char *dest, int x,int y, char ch  );
int format_float_coordinates( char *dest, double x,double y, char ch);


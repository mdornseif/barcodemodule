% bar = imread('bar128-1.png');
bar = imread('test1.png');
whos
more on
